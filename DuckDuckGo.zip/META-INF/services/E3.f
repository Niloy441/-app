B3.c
